# YouTube Subs Wordpress Widget

Widget to display a subscribe button and the option to show/hide the sub count and change layout

### Version
1.0.0